import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'HackerNews';
  public resultSet: any;
  public message: string = '';
  public showComment: boolean = false;
  public showReplyBox: boolean = false;
  public reply: string;
  public comment:string;
  constructor(private http: HttpClient){}

  ngOnInit(){
    this.getComments();
  }

  getComments(){
    this.http.get('http://localhost:3000/api/message').toPromise().then( (res) => {
      this.resultSet = res;
      console.log(this.resultSet);
    })
  }

  post(){
    console.log('Post', this.message);
    this.http.post('http://localhost:3000/api/message', this.message).toPromise().then(res => {
      console.log('Successfullly Inserted to DB');
      this.getComments();
    });
  }

  editComment(){
    // this.showComment = true;
  }

  replyComment(comment){
    // var reply = document.getElementById('replyText').value;
    // console.log('Reply =',  reply);
    this.comment = comment;
    this.showReplyBox = true;
  }

  submitReply(){
    this.showReplyBox = false;
    var body = {
      'comment': this.comment,
      'reply' : this.reply
    }
    console.log('Body =', body); 
    this.http.post('http://localhost:3000/api/message/reply', JSON.stringify(body)).toPromise().then(res => {
      console.log('Reply inserted');
      this.reply = '';
      this.getComments();
    });
  }

}
