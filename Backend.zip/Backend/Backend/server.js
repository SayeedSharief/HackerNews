const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const port = 3000;
const url = 'mongodb://localhost:27017';

app.use(bodyParser.text());
app.use(cors());

const dbName = 'commentsDB';
let db; 

app.post('/api/message', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    console.log('body =',req.body);
    db.collection('comments').insertOne({'comment': req.body, 'replies':[]});
    res.setStatus = 200;
    var result = {
        "res":"Success"
    }
    res.send(result);
});

app.get('/api/message', (req, res)=>{
    // res.setStatus = 200;
    db.collection('comments').find({}).toArray((err, docs) => {
        res.json(docs); 
    });
});

app.post('/api/message/reply', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    console.log('body =', req.body);
    var body = JSON.parse(req.body);
    db.collection('comments').update({'comment': body.comment},
    {$push: {'replies': body.reply}});
    res.setStatus = 200;
    var result = {
        "res":"Success"
    }
    res.send(result);
})


MongoClient.connect(url, function(err, client) {

    if(err) return console.log('Error in Mongo DB');

    console.log("Connected successfully to server");
   
    db = client.db(dbName);  

    // db.collection('messages').find({}).toArray((err, docs) => {
    //     console.log(docs);
    // });
});

app.get('/', (req, res) => {
    res.status(200).send();
    res.send('Hello');
});

app.listen(port, () => {
    console.log('Server listening at port', port);
    
});